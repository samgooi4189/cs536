EADME file for Programming Pairs
================================================

Programming Assignment Number: 2   
Date Completed:    

Partner 1     Name: Liang Zheng Gooi
Partner 1 CS Login: gooi

Partner 2     Name: Harshwardhan Newar
Partner 2 CS Login: harshwar

