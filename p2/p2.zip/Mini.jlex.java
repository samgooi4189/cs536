import java_cup.runtime.*; // defines the Symbol class
// The generated scanner will return a Symbol for each token that it finds.
// A Symbol contains an Object field named value; that field will be of type
// TokenVal, defined below.
//
// A TokenVal object contains the line number on which the token occurs as
// well as the number of the character on that line that starts the token.
// Some tokens (literals and IDs) also include the value of the token.
class TokenVal {
  // fields
    int linenum;
    int charnum;
  // constructor
    TokenVal(int line, int ch) {
        linenum = line;
        charnum = ch;
    }
}
class IntLitTokenVal extends TokenVal {
  // new field: the value of the integer literal
    int intVal;
  // constructor
    IntLitTokenVal(int line, int ch, int val) {
        super(line, ch);
        intVal = val;
    }
}
class IdTokenVal extends TokenVal {
  // new field: the value of the identifier
    String idVal;
  // constructor
    IdTokenVal(int line, int ch, String val) {
        super(line, ch);
    idVal = val;
    }
}
class StrLitTokenVal extends TokenVal {
  // new field: the value of the string literal
    String strVal;
  // constructor
    StrLitTokenVal(int line, int ch, String val) {
        super(line, ch);
        strVal = val;
    }
}
// The following class is used to keep track of the character number at which
// the current token starts on its line.
class CharNum {
    static int num=1;
}


class Yylex implements java_cup.runtime.Scanner {
	private final int YY_BUFFER_SIZE = 512;
	private final int YY_F = -1;
	private final int YY_NO_STATE = -1;
	private final int YY_NOT_ACCEPT = 0;
	private final int YY_START = 1;
	private final int YY_END = 2;
	private final int YY_NO_ANCHOR = 4;
	private final char YYEOF = '\uFFFF';
	private java.io.BufferedReader yy_reader;
	private int yy_buffer_index;
	private int yy_buffer_read;
	private int yy_buffer_start;
	private int yy_buffer_end;
	private char yy_buffer[];
	private int yyline;
	private int yy_lexical_state;

	Yylex (java.io.Reader reader) {
		this ();
		if (null == reader) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(reader);
	}

	Yylex (java.io.InputStream instream) {
		this ();
		if (null == instream) {
			throw (new Error("Error: Bad input stream initializer."));
		}
		yy_reader = new java.io.BufferedReader(new java.io.InputStreamReader(instream));
	}

	private Yylex () {
		yy_buffer = new char[YY_BUFFER_SIZE];
		yy_buffer_read = 0;
		yy_buffer_index = 0;
		yy_buffer_start = 0;
		yy_buffer_end = 0;
		yyline = 0;
		yy_lexical_state = YYINITIAL;
	}

	private boolean yy_eof_done = false;
	private final int YYINITIAL = 0;
	private final int yy_state_dtrans[] = {
		0
	};
	private void yybegin (int state) {
		yy_lexical_state = state;
	}
	private char yy_advance ()
		throws java.io.IOException {
		int next_read;
		int i;
		int j;

		if (yy_buffer_index < yy_buffer_read) {
			return yy_buffer[yy_buffer_index++];
		}

		if (0 != yy_buffer_start) {
			i = yy_buffer_start;
			j = 0;
			while (i < yy_buffer_read) {
				yy_buffer[j] = yy_buffer[i];
				++i;
				++j;
			}
			yy_buffer_end = yy_buffer_end - yy_buffer_start;
			yy_buffer_start = 0;
			yy_buffer_read = j;
			yy_buffer_index = j;
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YYEOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}

		while (yy_buffer_index >= yy_buffer_read) {
			if (yy_buffer_index >= yy_buffer.length) {
				yy_buffer = yy_double(yy_buffer);
			}
			next_read = yy_reader.read(yy_buffer,
					yy_buffer_read,
					yy_buffer.length - yy_buffer_read);
			if (-1 == next_read) {
				return YYEOF;
			}
			yy_buffer_read = yy_buffer_read + next_read;
		}
		return yy_buffer[yy_buffer_index++];
	}
	private void yy_move_start () {
		if ((byte) '\n' == yy_buffer[yy_buffer_start]) {
			++yyline;
		}
		++yy_buffer_start;
	}
	private void yy_pushback () {
		--yy_buffer_end;
	}
	private void yy_mark_start () {
		int i;
		for (i = yy_buffer_start; i < yy_buffer_index; ++i) {
			if ((byte) '\n' == yy_buffer[i]) {
				++yyline;
			}
		}
		yy_buffer_start = yy_buffer_index;
	}
	private void yy_mark_end () {
		yy_buffer_end = yy_buffer_index;
	}
	private void yy_to_mark () {
		yy_buffer_index = yy_buffer_end;
	}
	private java.lang.String yytext () {
		return (new java.lang.String(yy_buffer,
			yy_buffer_start,
			yy_buffer_end - yy_buffer_start));
	}
	private int yylength () {
		return yy_buffer_end - yy_buffer_start;
	}
	private char[] yy_double (char buf[]) {
		int i;
		char newbuf[];
		newbuf = new char[2*buf.length];
		for (i = 0; i < buf.length; ++i) {
			newbuf[i] = buf[i];
		}
		return newbuf;
	}
	private final int YY_E_INTERNAL = 0;
	private final int YY_E_MATCH = 1;
	private java.lang.String yy_error_string[] = {
		"Error: Internal error.\n",
		"Error: Unmatched input.\n"
	};
	private void yy_error (int code,boolean fatal) {
		java.lang.System.out.print(yy_error_string[code]);
		java.lang.System.out.flush();
		if (fatal) {
			throw new Error("Fatal Error.\n");
		}
	}
	private int yy_acpt[] = {
		YY_NOT_ACCEPT,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NOT_ACCEPT,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR,
		YY_NO_ANCHOR
	};
	private int yy_cmap[] = {
		0, 0, 0, 0, 0, 0, 0, 0,
		0, 1, 2, 0, 0, 3, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0,
		0, 0, 0, 0, 0, 0, 0, 0,
		1, 4, 5, 6, 0, 0, 7, 8,
		9, 10, 11, 12, 13, 14, 0, 15,
		16, 16, 16, 16, 16, 16, 16, 16,
		16, 16, 0, 17, 18, 19, 20, 0,
		0, 21, 21, 21, 21, 21, 21, 21,
		21, 21, 21, 21, 21, 21, 21, 21,
		21, 21, 21, 21, 21, 21, 21, 21,
		21, 21, 21, 0, 22, 0, 0, 21,
		0, 21, 21, 21, 21, 21, 21, 21,
		21, 21, 21, 21, 21, 21, 23, 21,
		21, 21, 21, 21, 23, 21, 21, 21,
		21, 21, 21, 24, 25, 26, 0, 0
		
	};
	private int yy_rmap[] = {
		0, 1, 2, 1, 3, 1, 1, 1,
		1, 1, 1, 4, 5, 1, 6, 7,
		8, 9, 1, 1, 1, 10, 1, 1,
		1, 1, 1, 1, 1, 1, 11, 1,
		12, 13, 14, 15, 16, 10, 17, 18,
		19, 20, 21, 12, 22, 20 
	};
	private int yy_nxt[][] = {
		{ 1, 2, 3, 1, 33, 37, 4, 40,
			1, 5, 6, 7, 8, 9, 10, 11,
			12, 13, 14, 15, 16, 17, 1, 17,
			18, 42, 19 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, 2, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ 4, 4, 34, 4, 4, 4, 4, 4,
			4, 4, 4, 4, 4, 4, 4, 4,
			4, 4, 4, 4, 4, 4, 4, 4,
			4, 4, 4 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, 4,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			12, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, 24, 25, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, 26, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, 27, 28, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			17, -1, -1, -1, -1, 17, -1, 17,
			-1, -1, -1 
		},
		{ 21, 21, 35, 21, 21, 22, 21, 21,
			21, 21, 21, 21, 21, 21, 21, 21,
			21, 21, 21, 21, 21, 21, 38, 21,
			21, 21, 21 
		},
		{ 30, 30, 36, 30, 30, 31, 30, 30,
			30, 30, 30, 30, 30, 30, 30, 30,
			30, 30, 30, 30, 30, 30, 36, 30,
			30, 30, 30 
		},
		{ 43, 43, 35, 43, 43, 22, 43, 43,
			43, 43, 43, 43, 43, 43, 43, 43,
			43, 43, 43, 43, 43, 43, 44, 43,
			43, 43, 43 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, 20, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ -1, -1, 34, 34, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ 35, 35, 35, 35, 35, -1, 35, 35,
			35, 35, 35, 35, 35, 35, 35, 35,
			35, 35, 35, 35, 35, 35, 35, 35,
			35, 35, 35 
		},
		{ 36, 36, 36, 36, 36, -1, 36, 36,
			36, 36, 36, 36, 36, 36, 36, 36,
			36, 36, 36, 36, 36, 36, 36, 36,
			36, 36, 36 
		},
		{ 41, 41, 41, 41, 41, 32, 41, 41,
			43, 41, 41, 41, 41, 41, 41, 41,
			41, 41, 41, 41, 41, 41, 43, 43,
			41, 41, 41 
		},
		{ 45, 45, 45, 45, 45, -1, 45, 45,
			36, 45, 45, 45, 45, 45, 45, 45,
			45, 45, 45, 45, 45, 45, 36, 36,
			45, 45, 45 
		},
		{ -1, -1, -1, -1, -1, -1, -1, 23,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1 
		},
		{ 30, 30, 36, 30, 30, 31, 30, 30,
			30, 30, 30, 30, 30, 30, 30, 30,
			30, 30, 30, 30, 30, 30, 39, 30,
			30, 30, 30 
		},
		{ -1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, -1, -1, -1, -1, -1, -1, -1,
			-1, 29, -1 
		},
		{ 35, 35, 35, 35, 35, 32, 35, 35,
			43, 35, 35, 35, 35, 35, 35, 35,
			35, 35, 35, 35, 35, 35, 43, 43,
			35, 35, 35 
		}
	};
	public java_cup.runtime.Symbol next_token ()
		throws java.io.IOException {
		char yy_lookahead;
		int yy_anchor = YY_NO_ANCHOR;
		int yy_state = yy_state_dtrans[yy_lexical_state];
		int yy_next_state = YY_NO_STATE;
		int yy_last_accept_state = YY_NO_STATE;
		boolean yy_initial = true;
		int yy_this_accept;

		yy_mark_start();
		yy_this_accept = yy_acpt[yy_state];
		if (YY_NOT_ACCEPT != yy_this_accept) {
			yy_last_accept_state = yy_state;
			yy_mark_end();
		}
		while (true) {
			yy_lookahead = yy_advance();
			yy_next_state = YY_F;
			if (YYEOF != yy_lookahead) {
				yy_next_state = yy_nxt[yy_rmap[yy_state]][yy_cmap[yy_lookahead]];
			}
			if (YY_F != yy_next_state) {
				yy_state = yy_next_state;
				yy_initial = false;
				yy_this_accept = yy_acpt[yy_state];
				if (YY_NOT_ACCEPT != yy_this_accept) {
					yy_last_accept_state = yy_state;
					yy_mark_end();
				}
			}
			else {
				if (YYEOF == yy_lookahead && true == yy_initial) {

return new Symbol(sym.EOF);
				}
				else if (YY_NO_STATE == yy_last_accept_state) {
					throw (new Error("Lexical Error: Unmatched Input."));
				}
				else {
					yy_to_mark();
					yy_anchor = yy_acpt[yy_last_accept_state];
					if (0 != (YY_END & yy_anchor)) {
						yy_pushback();
					}
					if (0 != (YY_START & yy_anchor)) {
						yy_move_start();
					}
					switch (yy_last_accept_state) {
					case 1:
						{ Errors.fatal(yyline+1, CharNum.num,
                         "ignoring illegal character: " + yytext());
            CharNum.num++;
          }
					case -2:
						break;
					case 2:
						{ CharNum.num += yytext().length(); }
					case -3:
						break;
					case 3:
						{ CharNum.num = 1; }
					case -4:
						break;
					case 4:
						{ CharNum.num = 1; }
					case -5:
						break;
					case 5:
						{ Symbol s = new Symbol(sym.LPAREN, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -6:
						break;
					case 6:
						{ Symbol s = new Symbol(sym.RPAREN, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -7:
						break;
					case 7:
						{ Symbol s = new Symbol(sym.TIMES, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -8:
						break;
					case 8:
						{ Symbol S = new Symbol(sym.PLUS, new TokenVal(yyline+1, CharNum.num));
          	  CharNum.num++;
          	  return S;
        }
					case -9:
						break;
					case 9:
						{ Symbol s = new Symbol(sym.COMMA, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -10:
						break;
					case 10:
						{ Symbol s = new Symbol(sym.MINUS, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -11:
						break;
					case 11:
						{ Symbol s = new Symbol(sym.DIVIDE, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -12:
						break;
					case 12:
						{ // NOTE: the following computation of the integer value does NOT
            //       check for overflow.  This must be changed.
	    int val = 0;
	    try{
	    if(Integer.decode(yytext()) > Integer.MAX_VALUE){
	    	Errors.warn(yyline+1, CharNum.num,
                         "integer literal too large; using max value");
	    	val = Integer.MAX_VALUE;
	    }
	    else{
            	val = (new Integer(yytext())).intValue();
	    }
            Symbol S = new Symbol(sym.INTLITERAL,
                             new IntLitTokenVal(yyline+1, CharNum.num, val));
            CharNum.num+=yytext().length();
            return S;
	    }catch(NumberFormatException ex){
	    	Errors.warn(yyline+1, CharNum.num,
                         "integer literal too large; using max value");
	    	val = Integer.MAX_VALUE;
		Symbol S = new Symbol(sym.INTLITERAL,
                             new IntLitTokenVal(yyline+1, CharNum.num, val));
            	CharNum.num+=yytext().length();
            	return S;
	    }
          }
					case -13:
						break;
					case 13:
						{ Symbol s = new Symbol(sym.SEMICOLON, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -14:
						break;
					case 14:
						{ Symbol s = new Symbol(sym.LESS, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -15:
						break;
					case 15:
						{ Symbol s = new Symbol(sym.ASSIGN, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -16:
						break;
					case 16:
						{ Symbol s = new Symbol(sym.GREATER, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -17:
						break;
					case 17:
						{
			  if(yytext().equals("int")){
				Symbol s = new Symbol(sym.INT, new TokenVal(yyline+1, CharNum.num));
		  		CharNum.num+=3;
		  		return s;
			  }
			  else if(yytext().equals("false")){
				Symbol s = new Symbol(sym.FALSE, new TokenVal(yyline+1, CharNum.num));
		  		CharNum.num+=5;
				return s;
			  }
			  else if(yytext().equals("write")){
				Symbol s = new Symbol(sym.WRITE, new TokenVal(yyline+1, CharNum.num));
		  		CharNum.num+=5;
		  		return s;
			  }
			  else if(yytext().equals("bool")){
				Symbol s = new Symbol(sym.BOOL, new TokenVal(yyline+1, CharNum.num));
		  		CharNum.num+=4;
		  		return s;
			  }
			  else if(yytext().equals("if")){
				Symbol s = new Symbol(sym.IF, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=2;
		 		return s;
			  }
			  else if(yytext().equals("return")){
				Symbol s = new Symbol(sym.RETURN, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=6;
		 		return s;
			  }
			  else if(yytext().equals("true")){
				Symbol s = new Symbol(sym.TRUE, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=4;
		 		return s;
			  }
			  else if(yytext().equals("cin")){
				Symbol s = new Symbol(sym.CIN, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=3;
		 		return s;
			  }
			  else if(yytext().equals("void")){
				Symbol s = new Symbol(sym.VOID, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=4;
		 		return s;
			  }
			  else if(yytext().equals("else")){
				Symbol s = new Symbol(sym.ELSE, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=4;
		 		return s;
			  }
			  else if(yytext().equals("cout")){
				Symbol s = new Symbol(sym.COUT, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=4;
		 		return s;
			  }
			  else if(yytext().equals("read")){
				Symbol s = new Symbol(sym.READ, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=4;
		 		return s;
			  }
			  else if(yytext().equals("while")){
				Symbol s = new Symbol(sym.WHILE, new TokenVal(yyline+1, CharNum.num));
		 		CharNum.num+=5;
		 		return s;
			  }
			  else{
				Symbol s = new Symbol(sym.ID, new IdTokenVal(yyline+1, CharNum.num, yytext()));
		  		CharNum.num+=yytext().length();
		  		return s;
			  }
			}
					case -18:
						break;
					case 18:
						{ Symbol s = new Symbol(sym.LCURLY, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -19:
						break;
					case 19:
						{ Symbol s = new Symbol(sym.RCURLY, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num++;
		  return s;
	}
					case -20:
						break;
					case 20:
						{ Symbol s = new Symbol(sym.NOTEQUALS, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -21:
						break;
					case 21:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -22:
						break;
					case 22:
						{ 
		  Symbol s= new Symbol(sym.STRINGLITERAL, new StrLitTokenVal(yyline+1, CharNum.num, yytext()));
		  CharNum.num+=yytext().length();
		  return s;
		}
					case -23:
						break;
					case 23:
						{ Symbol s = new Symbol(sym.AND, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -24:
						break;
					case 24:
						{ Symbol s = new Symbol(sym.READ, new TokenVal(yyline+1, CharNum.num));
	  	CharNum.num+=2;
	  	return s;
	}
					case -25:
						break;
					case 25:
						{ Symbol s = new Symbol(sym.LESSEQ, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -26:
						break;
					case 26:
						{ Symbol s = new Symbol(sym.EQUALS, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -27:
						break;
					case 27:
						{ Symbol s = new Symbol(sym.GREATEREQ, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -28:
						break;
					case 28:
						{ Symbol s = new Symbol(sym.WRITE, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -29:
						break;
					case 29:
						{ Symbol s = new Symbol(sym.OR, new TokenVal(yyline+1, CharNum.num));
		  CharNum.num+=2;
		  return s;
	}
					case -30:
						break;
					case 30:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal with bad escaped character");
		}
					case -31:
						break;
					case 31:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring string literal with bad escaped character");
		}
					case -32:
						break;
					case 33:
						{ Errors.fatal(yyline+1, CharNum.num,
                         "ignoring illegal character: " + yytext());
            CharNum.num++;
          }
					case -33:
						break;
					case 34:
						{ CharNum.num = 1; }
					case -34:
						break;
					case 35:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -35:
						break;
					case 36:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal with bad escaped character");
		}
					case -36:
						break;
					case 37:
						{ Errors.fatal(yyline+1, CharNum.num,
                         "ignoring illegal character: " + yytext());
            CharNum.num++;
          }
					case -37:
						break;
					case 38:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -38:
						break;
					case 39:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal with bad escaped character");
		}
					case -39:
						break;
					case 40:
						{ Errors.fatal(yyline+1, CharNum.num,
                         "ignoring illegal character: " + yytext());
            CharNum.num++;
          }
					case -40:
						break;
					case 41:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -41:
						break;
					case 42:
						{ Errors.fatal(yyline+1, CharNum.num,
                         "ignoring illegal character: " + yytext());
            CharNum.num++;
          }
					case -42:
						break;
					case 43:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -43:
						break;
					case 44:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal");
		}
					case -44:
						break;
					case 45:
						{ 
		  CharNum.num=1;
		  Errors.fatal(yyline+1, CharNum.num,
                         "ignoring unterminated string literal with bad escaped character");
		}
					case -45:
						break;
					default:
						yy_error(YY_E_INTERNAL,false);
					case -1:
					}
					yy_initial = true;
					yy_state = yy_state_dtrans[yy_lexical_state];
					yy_next_state = YY_NO_STATE;
					yy_last_accept_state = YY_NO_STATE;
					yy_mark_start();
					yy_this_accept = yy_acpt[yy_state];
					if (YY_NOT_ACCEPT != yy_this_accept) {
						yy_last_accept_state = yy_state;
					}
				}
			}
		}
	}
}
